-- =====================================================
-- PNTT_OLD_CHILD_REF_DETAILS - Old Patient - Child Referral DETAIL
-- =====================================================
-- Disaggregated records for: Number of old child referrals + Test + Positive
-- Logic matches `PNTT_OLD_CHILD_REF_aggregate.sql`
-- =====================================================

SET @StartDate = '2025-04-01';
SET @EndDate   = '2025-06-30';

SELECT
    'PNTT_OLD_CHILD_REF' AS indicator_code,
    ai.ClinicID AS clinicid,
    ai.Sex AS caregiver_sex,
    CASE
        WHEN ai.Sex = 0 THEN 'Female'
        WHEN ai.Sex = 1 THEN 'Male'
        ELSE 'Unknown'
    END AS caregiver_sex_display,
    ai.DaBirth AS caregiver_date_of_birth,
    ai.DafirstVisit AS caregiver_first_visit_date,
    TIMESTAMPDIFF(YEAR, ai.DaBirth, @EndDate) AS caregiver_age,
    ai.TypeofReturn,
    ai.OffIn,
    pntt.AsID AS pntt_asid,
    pntt.DaVisit AS pntt_visit_date,
    child.CAPID AS child_id,
    child.Sex AS child_sex,
    CASE
        WHEN child.Sex = 0 THEN 'Female'
        WHEN child.Sex = 1 THEN 'Male'
        ELSE 'Unknown'
    END AS child_sex_display,
    child.PlanChild AS child_plan_code
FROM (
    SELECT ClinicID, Sex, TypeofReturn, OffIn, DaBirth, DafirstVisit
    FROM (
        SELECT ClinicID,
               Sex,
               TypeofReturn,
               OffIn,
               DaBirth,
               DafirstVisit,
               ROW_NUMBER() OVER (PARTITION BY ClinicID ORDER BY DafirstVisit ASC, OffIn ASC, TypeofReturn ASC) AS rn
        FROM tblaimain
        WHERE DafirstVisit BETWEEN @StartDate AND @EndDate
    ) ranked_adult
    WHERE rn = 1
) adultactive
RIGHT OUTER JOIN tblapntt pntt
    ON adultactive.ClinicID = pntt.ClinicID
LEFT OUTER JOIN (
    SELECT ClinicID,
           Sex,
           TypeofReturn,
           OffIn,
           DaBirth,
           DafirstVisit
    FROM (
        SELECT ClinicID,
               Sex,
               TypeofReturn,
               OffIn,
               DaBirth,
               DafirstVisit,
               ROW_NUMBER() OVER (PARTITION BY ClinicID ORDER BY DafirstVisit ASC, OffIn ASC, TypeofReturn ASC) AS rn
        FROM tblaimain
    ) ranked_ai
    WHERE rn = 1
) ai
    ON ai.ClinicID = pntt.ClinicID
LEFT OUTER JOIN tblapnttchild child
    ON pntt.AsID = child.AsID
WHERE pntt.Agree = 0
  AND child.PlanChild = 0
  AND pntt.DaVisit BETWEEN @StartDate AND @EndDate
  AND (adultactive.ClinicID IS NULL
       OR adultactive.OffIn = 1
       OR adultactive.TypeofReturn <> -1)
  AND child.CAPID IS NOT NULL
ORDER BY pntt_visit_date, clinicid, child_id;



