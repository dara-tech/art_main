-- =====================================================
-- PNTT_OLD_PART_REG - Old Patient - Partner Registered AGGREGATE
-- =====================================================
-- Old of Partner Register
-- =====================================================
-- PARAMETER SETUP
-- =====================================================
SET @StartDate = '2025-04-01';
SET @EndDate = '2025-06-30';

-- =====================================================
-- MAIN QUERY
SELECT
  COUNT(tblapnttpart.Sex) as Tsex,
  SUM(tblapnttpart.Sex=0) as Female,
  SUM(tblapnttpart.Sex=1) as Male
FROM (
SELECT ClinicID, Sex, TypeofReturn, OffIn
FROM (
    SELECT ClinicID,
           Sex,
           TypeofReturn,
           OffIn,
           ROW_NUMBER() OVER (PARTITION BY ClinicID ORDER BY DafirstVisit ASC, OffIn ASC, TypeofReturn ASC) AS rn
    FROM tblaimain
    WHERE DafirstVisit BETWEEN @StartDate AND @EndDate
) ranked_adult
WHERE rn = 1
) adultactive
RIGHT OUTER
JOIN tblapntt
ON adultactive.ClinicID = tblapntt.ClinicID
LEFT OUTER
JOIN tblapnttpart
ON tblapntt.AsID = tblapnttpart.AsID
WHERE tblapntt.Agree=0
AND tblapntt.DaVisit BETWEEN @StartDate AND @EndDate
AND (adultactive.ClinicID is null
OR adultactive.OffIn=1
OR adultactive.TypeofReturn<>-1);
